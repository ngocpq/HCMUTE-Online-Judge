﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcSiteMapProvider;

namespace SitemapDemo.Controllers
{
    public class NewsController : Controller
    {
        //
        // GET: /News/

        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /News/Sports/
        public ActionResult Sports()
        {
            return View();
        }

        //
        //GET: News/Article/x
        [MvcSiteMapNode(Title = "Article", ParentKey = "News")]
        public ActionResult Article(int id)
        {
            ViewBag.id = id;
            return View();
        }

    }
}
